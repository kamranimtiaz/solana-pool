use std::time::Duration;

#[deprecated(since = "2.2.3", note = "This symbol is now private interface.")]
pub const DEFAULT_TPU_COALESCE: Duration = Duration::from_millis(5);
