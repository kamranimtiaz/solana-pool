<h1 align="center">
  Kaigan
</h1>
<p align="center">
  Rust companion for <a href="https://github.com/metaplex-foundation/kinobi">Kinobi</a>.
</p>
<p align="center">
  <img width="600" alt="Metaplex Kaigan" src="https://github.com/metaplex-foundation/kaigan/assets/729235/450c4b42-632e-4398-bf55-ce8c501cc404" />
</p>
