# Rust client

A generated Rust library for the Config program.

## Getting started

To build and test your Rust client from the root of the repository, you may use the following command.

```sh
pnpm clients:js:test
```

This will start a new local validator, if one is not already running, and run the tests for your Rust client.
